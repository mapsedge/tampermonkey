# dreamwidth-monkey-update
Updates the Dreamwidth posting page, making changes to the navigation to bring it out of the 90s.

- Moves the navigation bar to the top of the interface and locks it in place
- Reorganizes the buttons to a more sensible order
- Adds upload button to the page toolbar
- Eliminates redundant buttons
- Adds "Save Draft" button to update page: (sets security to "private (just you)" and Saves.)
- Adds image selection to update textarea toolbar;
- - makes image url a dropdown, pulling from saved images on https://www.dreamwidth.org/file/list

